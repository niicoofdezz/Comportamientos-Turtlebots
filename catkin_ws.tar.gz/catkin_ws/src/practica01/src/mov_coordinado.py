#!/usr/bin/env python
# -*- coding: utf-8 -*-


import rospy
from geometry_msgs.msg import Twist
import math

N = 4

def movimiento (v, vel_lineal, vel_angular, tiempo):

    vel = Twist()
    vel.linear.x = vel_lineal
    vel.angular.z = vel_angular
    
    start_time = rospy.Time.now()
    rate = rospy.Rate(10)

    # se ejecuta hasta que se cumpla el tiempo especificado
    while rospy.Time.now() - start_time < rospy.Duration(tiempo):
        for i in range(len(v)):
            v[i].publish(vel)   # se envia el mensaje de velocidad a cada robot
        rate.sleep()    


if __name__ == "__main__":
    rospy.init_node("practica1", anonymous = True)

    v = []

    # se crea un publicador para cada robot y lo almacena en v
    for i in range(1, N+1):
        pub = rospy.Publisher("/robot{}/mobile_base/commands/velocity".format(i), Twist, queue_size=10)
        v.append(pub)

    rospy.sleep(1)

    # movimientos en forma de cuadrado
        # grados = w * t; w = 90/4 = (pi/2)/4
    movimiento(v, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 4)  # linea recta
    movimiento(v, vel_lineal = 0.0, vel_angular = (math.pi/2)/4, tiempo = 4) # gira 90º grados 
    
    movimiento(v, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 4) 
    movimiento(v, vel_lineal = 0.0, vel_angular = (math.pi/2)/4, tiempo = 4)

    movimiento(v, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 4)
    movimiento(v, vel_lineal = 0.0, vel_angular = (math.pi/2)/4, tiempo = 4) 
    
    movimiento(v, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 4) 
    movimiento(v, vel_lineal = 0.0, vel_angular = (math.pi/2)/4, tiempo = 4)

    rospy.loginfo("Movimiento realizado")
