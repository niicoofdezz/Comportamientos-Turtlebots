#!/usr/bin/env python
# -*- coding: utf-8 -*-


import rospy
from geometry_msgs.msg import Twist

N = 4

def movimiento (pub, vel_lineal, vel_angular, tiempo):

    vel = Twist()
    vel.linear.x = vel_lineal
    vel.angular.z = vel_angular
    
    start_time = rospy.Time.now()
    rate = rospy.Rate(10)

    # se ejecuta hasta que se cumpla el tiempo especificado
    while rospy.Time.now() - start_time < rospy.Duration(tiempo):
        pub.publish(vel)    # publica el mensaje de velocidad
        rate.sleep()    


if __name__ == "__main__":
    rospy.init_node("practica1", anonymous = True)

    v = []

    # crea un publicador para cada robot y lo almacena en v
    for i in range(1, N+1):
        pub = rospy.Publisher("/robot{}/mobile_base/commands/velocity".format(i), Twist, queue_size=10)
        v.append(pub)

    rospy.sleep(1)

    # movimiento en linea recta para cada robot
    for i in v:
        movimiento(i, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 5)
        rospy.sleep(1)

    # giro de 90 grados para cada robot
    for i in v:
        movimiento(i, vel_lineal = 0.0, vel_angular = 0.3142, tiempo = 5) # grados = w * t; w = 90/5 = (pi/2)/5 = 0.3142
        rospy.sleep(1)

    # otro movimiento en linea recta
    for i in v:
        movimiento(i, vel_lineal = 0.5, vel_angular = 0.0, tiempo = 5) 
        rospy.sleep(1)

    # detener el robot
    for i in v:
        movimiento(i, vel_lineal = 0.0, vel_angular = 0.0, tiempo = 0.5)
        rospy.sleep(1)

    rospy.loginfo("Movimiento realizado")
