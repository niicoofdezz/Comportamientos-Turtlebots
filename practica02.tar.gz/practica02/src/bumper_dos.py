#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import BumperEvent
import random
from functools import partial

# Variables globales
robots = [
    {'name': 'robot1', 'bump': False, 'bump_side': None, 'vel_pub': None},
    {'name': 'robot2', 'bump': False, 'bump_side': None, 'vel_pub': None},
]

def processBump(i, data):
    robot = robots[i]
    
    if data.state == BumperEvent.PRESSED:
        robot['bump'] = True
        robot['bump_side'] = data.bumper  # 0 = Izquierdo, 1 = Centro, 2 = Derecho
        rospy.loginfo("%s detectó colisión en el bumper %d" % (robot['name'], data.bumper))
    else:
        robot['bump'] = False
        rospy.loginfo("%s liberó el bumper" % robot['name'])

def move_robot():
    rospy.init_node('comportamiento_reactivo')
    rate = rospy.Rate(10)  # 10 Hz

    # Inicializar el publicador y suscripción para cada robot
    for i in range(len(robots)):
        robots[i]['vel_pub'] = rospy.Publisher('/%s/mobile_base/commands/velocity' % robots[i]['name'], Twist, queue_size=10)
        rospy.Subscriber('/%s/mobile_base/events/bumper' % robots[i]['name'], BumperEvent, partial(processBump, i))

    while not rospy.is_shutdown():
        for robot in robots:
            twist = Twist()
            
            if robot['bump']:  # Si hay colisión...
                twist.linear.x = 0  # Detener el robot
                robot['vel_pub'].publish(twist)
                rospy.sleep(0.5)
                
                # Lógica para girar según el lado del bumper activado
                if robot['bump_side'] == 0:
                    rospy.loginfo("%s reaccionando al bumper Izquierdo" % robot['name'])
                    twist.angular.z = -1.0
                    twist.linear.x = -0.2
                elif robot['bump_side'] == 1:
                    rospy.loginfo("%s reaccionando al bumper Central" % robot['name'])
                    if random.randint(0, 1) == 0:
                        twist.angular.z = 1.5
                    else:
                        twist.angular.z = -1.5
                    twist.linear.x = -0.4
                elif robot['bump_side'] == 2:
                    rospy.loginfo("%s reaccionando al bumper Derecho" % robot['name'])
                    twist.angular.z = 1.0
                    twist.linear.x = -0.2

                robot['vel_pub'].publish(twist)
                rospy.sleep(1)
                
                # Verificación para evitar que el bumper se quede trabado
                robot['bump'] = False
                rospy.loginfo("%s reseteando estado de bumper" % robot['name'])
            else:
                twist.linear.x = 0.2  # Moverse hacia adelante
                twist.angular.z = 0
                robot['vel_pub'].publish(twist)
        
        rate.sleep()

if __name__ == '__main__':
    try:
        move_robot()
    except rospy.ROSInterruptException:
        pass

