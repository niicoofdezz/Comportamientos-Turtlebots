#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import BumperEvent
import random

# Variables globales
bump = False
bump_side = None

def processBump(data):
    global bump, bump_side
    if data.state == BumperEvent.PRESSED:
        bump = True
        bump_side = data.bumper  # 0 = Izquierdo, 1 = Centro, 2 = Derecho
    else:
        bump = False

    
    # En función del bumper presionado, hará un movimiento u otro
        
   
def move_robot():
    global bump, bump_side
    rospy.init_node('comportamiento_reactivo')

    # Publicador de velocidad
    vel_pub = rospy.Publisher('/robot1/mobile_base/commands/velocity', Twist, queue_size=10)
    
    # Suscriptor del bumper
    rospy.Subscriber('/robot1/mobile_base/events/bumper', BumperEvent, processBump)

    rate = rospy.Rate(10)  # 10 Hz
    twist = Twist()

    while not rospy.is_shutdown():
        if bump:    # si hay colision...
            
            twist.linear.x = 0          # el robot se para
            vel_pub.publish(twist)
            rospy.sleep(0.5)

            # y gira en función del lado que haya colisionado
            if bump_side == 0:  # Izquierdo
                rospy.loginfo("Reaccionando al bumper Izquierdo")
                twist.angular.z = -1.0
                twist.linear.x = -0.2
            elif bump_side == 1:  # Centro
                rospy.loginfo("Reaccionando al bumper Central")
                aux = random.randint(0,1) # para dotar al turtlebot de cierto grado de aleatoriedad
                if aux == 0:
                    twist.angular.z = 1.5
                    twist.linear.x = -0.4
                elif aux == 1:
                    twist.angular.z = -1.5
                    twist.linear.x = -0.4
                
                
            elif bump_side == 2:  # Derecho
                rospy.loginfo("Reaccionando al bumper Derecho")
                twist.angular.z = 1.0
                twist.linear.x = -0.2

            vel_pub.publish(twist)
            rospy.sleep(1)
  
            twist.angular.z = 0  # deja de girar
            bump = False         # y resetea el estado del bumper

        else: # si no hay colision...
            
            twist.linear.x = 0.2    # moverse hacia delante
            twist.angular.z = 0

        vel_pub.publish(twist)
        rate.sleep()

if __name__ == '__main__':
    try:
        move_robot()
    except rospy.ROSInterruptException:
        pass
